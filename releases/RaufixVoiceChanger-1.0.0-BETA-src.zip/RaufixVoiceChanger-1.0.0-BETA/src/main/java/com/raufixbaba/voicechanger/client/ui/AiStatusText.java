package com.raufixbaba.voicechanger.client.ui;

import java.util.Locale;
import net.minecraft.network.chat.Component;
import com.raufixbaba.voicechanger.client.i18n.RaufixI18n;
import net.minecraft.network.chat.MutableComponent;
import com.raufixbaba.voicechanger.client.VoiceChangerController;
import com.raufixbaba.voicechanger.client.ai.AiVoiceController;
import com.raufixbaba.voicechanger.client.ai.engine.EngineKind;
import com.raufixbaba.voicechanger.client.ai.engine.EngineStatus;
import com.raufixbaba.voicechanger.client.ai.install.EngineInstaller;
import com.raufixbaba.voicechanger.client.ai.runtime.AiVoiceRuntime;

/**
 * The words and colours the AI tab uses to say what is going on: one line per
 * engine, and one line on what the player is heard as right now.
 *
 * <p>Kept apart from the screen because the screen is layout and buttons,
 * while this is the part that has to stay right as states are added.</p>
 */
final class AiStatusText {
    static final int GREEN = 0xFF66DD66;
    static final int YELLOW = 0xFFFFCC55;
    static final int RED = 0xFFFF7777;
    static final int GREY = 0xFFAAAAAA;

    private AiStatusText() {
    }

    /** "Voice Changer Engine: ready - RTX 4060 Ti", marked when it is the one speaking. */
    static Component engineLine(AiVoiceController ai, EngineKind kind) {
        EngineStatus status = ai.status(kind);
        Component state = Component.translatable(status.availability().translationKey());
        String marker = kind == ai.runningEngine() ? "> " : "  ";

        MutableComponent line = Component.literal(marker)
                .append(Component.translatable(kind.translationKey()))
                .append(": ")
                .append(state);
        if (!status.detail().isBlank()) {
            line.append(" - " + status.detail());
        }
        return line;
    }

    static int engineColor(EngineStatus status) {
        return switch (status.availability()) {
            case READY -> GREEN;
            case NO_MODEL -> YELLOW;
            case CHECKING, STARTING, NOT_RUNNING, NO_KEY -> GREY;
            case BAD_KEY, NO_CREDITS, FAILED -> RED;
        };
    }

    /** What other players hear, and if it is not the AI voice, the one thing in the way. */
    static Component nowLine(VoiceChangerController addon) {
        AiVoiceController ai = addon.aiVoice();
        if (!addon.isAiAllowedByServer()) {
            return RaufixI18n.tr("raufixvc.ai.now.server_denied");
        }
        if (!ai.isSelected()) {
            return RaufixI18n.tr("raufixvc.ai.now.effects");
        }
        if (!addon.isEffectEnabled()) {
            return RaufixI18n.tr("raufixvc.ai.now.switched_off");
        }

        EngineKind running = ai.runningEngine();
        if (running != null) {
            return RaufixI18n.tr("raufixvc.ai.now.speaking",
                    Component.translatable(running.translationKey()), delayOf(ai, running));
        }
        if (ai.isLoadingVoice()) {
            return RaufixI18n.tr("raufixvc.ai.now.loading_voice");
        }
        if (ai.startFailure() != null) {
            return RaufixI18n.tr("raufixvc.ai.now.failed", ai.startFailure());
        }
        return RaufixI18n.tr("raufixvc.ai.now.none_ready");
    }

    /**
     * The one next step, in words, for whichever engine the player is aiming
     * at; empty once the AI voice is speaking or not wanted. Players who see
     * "not ready" without this have no idea what to do about it.
     */
    static Component hintLine(VoiceChangerController addon) {
        AiVoiceController ai = addon.aiVoice();
        if (!addon.isAiAllowedByServer() || !ai.isSelected() || !addon.isEffectEnabled()
                || ai.runningEngine() != null) {
            return Component.empty();
        }

        // Before any engine has answered, "auto" points nowhere, and "pick a
        // way below" would send someone off who already picked the engine.
        if (ai.installer().progress().state() == EngineInstaller.State.INSTALLING) {
            return RaufixI18n.tr("raufixvc.ai.hint.engine",
                    Component.translatable(EngineKind.VOICE_ENGINE.translationKey()),
                    RaufixI18n.tr("raufixvc.ai.hint.installing"));
        }
        EngineKind target = ai.targetEngine();
        if (target == null) {
            return RaufixI18n.tr("raufixvc.ai.hint.start");
        }
        if (target == EngineKind.VOICE_ENGINE && !ai.installer().isInstalled()) {
            return RaufixI18n.tr("raufixvc.ai.hint.not_installed");
        }
        EngineStatus status = ai.status(target);
        if (status.availability() == EngineStatus.Availability.STARTING && !status.detail().isBlank()) {
            return RaufixI18n.tr("raufixvc.ai.hint.engine",
                    Component.translatable(target.translationKey()),
                    RaufixI18n.tr("raufixvc.ai.hint.starting_stage", status.detail()));
        }
        return RaufixI18n.tr("raufixvc.ai.hint.engine",
                Component.translatable(target.translationKey()),
                RaufixI18n.tr("raufixvc.ai.hint."
                        + status.availability().name().toLowerCase(Locale.ROOT)));
    }

    static int nowColor(VoiceChangerController addon) {
        AiVoiceController ai = addon.aiVoice();
        if (!addon.isAiAllowedByServer() || ai.startFailure() != null && ai.runningEngine() == null) {
            return RED;
        }
        if (ai.runningEngine() != null) {
            return GREEN;
        }
        return ai.isSelected() && addon.isEffectEnabled() ? YELLOW : GREY;
    }

    /**
     * A live engine is about one chunk and one round trip behind; a phrase
     * engine speaks once the phrase is over, which cannot be put in numbers.
     */
    private static Component delayOf(AiVoiceController ai, EngineKind running) {
        AiVoiceRuntime.LiveTiming timing = ai.liveTiming();
        if (running.delivery() == EngineKind.Delivery.PHRASE || timing == null) {
            return RaufixI18n.tr("raufixvc.ai.delay.phrase");
        }
        long millis = timing.chunkFrames() * 20L + timing.roundTripMillis();
        return RaufixI18n.tr("raufixvc.ai.delay.live", millis);
    }
}
